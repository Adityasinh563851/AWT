var a;
let b;
const c=0;
myFunction();
function myFunction(){
    console.log('Hello');
    console.log(a);
    document.write("Hello");
}
a=10;
