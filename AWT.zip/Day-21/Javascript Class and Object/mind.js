class Abc{
    constructor(a,b){
        this.a=a
        this.b=b
    }
    sum(){
        let c=this.a+this.b;
        console.log("The sum is " + c)
    }
}
let d=new Abc(2,4)
d.sum();


