function externalAlert(){
    alert('External Alert');
}

function externalConfirm()
{
    if(confirm('Are you Sure?')){
    alert('Yes!!!');
    }
    else{
        console.error("No!!!");
    }
}

function externalPrompt(){
    var b=prompt("Enter Your Name");
    console.log("Hello  " + b);
}

function changeBackground()
{
    document.body.style.backgroundColor='red';/*document.getElementById('bgchoose').value;*/
}

function changeBackgroundcolordiv(){
    document.getElementById('D1').style.backgroundColor='yellow'/*document.getElementById('colorpicker').value;*/
}