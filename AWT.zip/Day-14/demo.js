var arr1 = [1, 2, 3, 4, 5, 6, 7, 8, 9]
console.log(arr1);

document.getElementById('P1').innerHTML = "Actual array: " + arr1;
arr1.push(10);

document.getElementById('P2').innerHTML = "After Push: " + arr1;
arr1.pop();

document.getElementById('P3').innerHTML = "After Pop: " + arr1;
var arr2=[786 , 420];
var arr3=arr1.concat(arr2);

document.getElementById('P4').innerHTML = "After Concat: " + arr3;
arr1.splice(1,2)

document.getElementById('P5').innerHTML = "After splice: " + arr1;

var arr4=['car', 'bike', 'truck' , 'motorcycle']
arr5 = arr4.slice(1,3)
document.getElementById('P6').innerHTML = "After slice: " + arr5;

var length=arr1.length;
document.getElementById('P7').innerHTML = "After length: " + length;

arr1.reverse();
document.getElementById('P8').innerHTML = "After Reverse: " + arr1;

arr1.sort();
document.getElementById('P9').innerHTML = "After sort: " + arr1;

arr1.fill(32,1,3);
document.getElementById('P10').innerHTML = "After fill: " + arr1;

var str=arr1.toString();
document.getElementById('P11').innerHTML = "After toString: " + arr1;

arr1.shift();
document.getElementById('P12').innerHTML = "After shift: " + arr1;

var x=arr1.join('|');
document.getElementById('P13').innerHTML = "After join: " + x;

arr1.unshift(20,21);
document.getElementById('P14').innerHTML = "After unshift: " + arr1;

var s=arr1.indexOf(7);
document.getElementById('P15').innerHTML = "indexOf 7: " + s;

var v=arr1.lastIndexOf(32);
document.getElementById('P16').innerHTML = "lastIndexOf 32: " + v;

var find=arr1.includes(7);
document.getElementById('P17').innerHTML = "findIndex 7: " + find;
